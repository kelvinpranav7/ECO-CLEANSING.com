# accounts/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import CustomUser

def home(request):
    return render(request, 'accounts/home.html')

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        role = request.POST.get('role', 'user')
        
        if password != password2:
            messages.error(request, 'Passwords do not match!')
            return render(request, 'accounts/register.html')
        
        if CustomUser.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists!')
            return render(request, 'accounts/register.html')
        
        if CustomUser.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists!')
            return render(request, 'accounts/register.html')
        
        user = CustomUser.objects.create_user(
            username=username,
            email=email,
            password=password,
            role=role
        )
        messages.success(request, 'Registration successful! Please login.')
        return redirect('login')
    
    return render(request, 'accounts/register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            if user.role == 'admin':
                return redirect('admin_dashboard')
            else:
                return redirect('user_dashboard')
        else:
            messages.error(request, 'Invalid username or password!')
    
    return render(request, 'accounts/login.html')

def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully!')
    return redirect('home')

@login_required
def user_dashboard(request):
    if request.user.role != 'user':
        return redirect('admin_dashboard')  # No message needed
    return render(request, 'accounts/user_dashboard.html')
    
@login_required
def admin_dashboard(request):
    if request.user.role != 'admin':
        messages.error(request, 'Access denied!')
        return redirect('user_dashboard')
    
    users = CustomUser.objects.all()
    return render(request, 'accounts/admin_dashboard.html', {'users': users})

def index(request):
    return render(request, 'accounts/index.html')

# NEW FUNCTIONS - Make sure they start at the LEFT margin (no extra spaces)
@login_required
def delete_user(request, user_id):
    if request.user.role != 'admin':
        messages.error(request, 'Access denied! Admin only.')
        return redirect('home')
    
    user_to_delete = get_object_or_404(CustomUser, id=user_id)
    
    if user_to_delete == request.user:
        messages.error(request, 'You cannot delete yourself!')
        return redirect('admin_dashboard')
    
    username = user_to_delete.username
    user_to_delete.delete()
    messages.success(request, f'User "{username}" has been deleted successfully!')
    return redirect('admin_dashboard')

@login_required
def toggle_user_status(request, user_id):
    if request.user.role != 'admin':
        messages.error(request, 'Access denied! Admin only.')
        return redirect('home')
    
    user_to_toggle = get_object_or_404(CustomUser, id=user_id)
    
    if user_to_toggle == request.user:
        messages.error(request, 'You cannot deactivate yourself!')
        return redirect('admin_dashboard')
    
    user_to_toggle.is_active = not user_to_toggle.is_active
    user_to_toggle.save()
    
    status = "activated" if user_to_toggle.is_active else "deactivated"
    messages.success(request, f'User "{user_to_toggle.username}" has been {status}!')
    return redirect('admin_dashboard')

@login_required
def change_user_role(request, user_id):
    if request.user.role != 'admin':
        messages.error(request, 'Access denied! Admin only.')
        return redirect('home')
    
    user_to_change = get_object_or_404(CustomUser, id=user_id)
    
    if user_to_change == request.user:
        messages.error(request, 'You cannot change your own role!')
        return redirect('admin_dashboard')
    
    if user_to_change.role == 'user':
        user_to_change.role = 'admin'
    else:
        user_to_change.role = 'user'
    
    user_to_change.save()
    messages.success(request, f'User "{user_to_change.username}" role changed to {user_to_change.role}!')
    return redirect('admin_dashboard')