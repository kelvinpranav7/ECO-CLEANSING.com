# accounts/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('user-dashboard/', views.user_dashboard, name='user_dashboard'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('index/', views.index, name='index'),
    
    # ADD THESE THREE NEW LINES:
    path('admin/delete-user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('admin/toggle-status/<int:user_id>/', views.toggle_user_status, name='toggle_user_status'),
    path('admin/change-role/<int:user_id>/', views.change_user_role, name='change_user_role'),
]