#pickups/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # User URLs
    path('create/', views.create_pickup_request, name='create_pickup_request'),
    path('my-requests/', views.view_pickup_requests, name='view_pickup_requests'),
    path('detail/<int:pk>/', views.pickup_detail, name='pickup_detail'),
    path('cancel/<int:pk>/', views.cancel_pickup_request, name='cancel_pickup_request'),
    
    # Admin URLs - RENAMED TO AVOID CONFLICT
    path('admin/pickups-dashboard/', views.pickups_admin_dashboard, name='pickups_admin_dashboard'),
    path('admin/update/<int:pk>/', views.admin_update_request, name='admin_update_request'),
]