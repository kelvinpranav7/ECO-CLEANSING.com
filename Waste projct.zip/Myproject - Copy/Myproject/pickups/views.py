#pickups/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Q
from .models import PickupRequest
from .forms import PickupRequestForm

# USER VIEWS
@login_required
def create_pickup_request(request):
    """Create a new pickup request"""
    if request.method == 'POST':
        form = PickupRequestForm(request.POST)
        if form.is_valid():
            pickup_request = form.save(commit=False)
            pickup_request.user = request.user
            pickup_request.save()
            messages.success(request, 'Pickup request created successfully!')
            return redirect('view_pickup_requests')
    else:
        form = PickupRequestForm()
    
    return render(request, 'pickups/create_pickup.html', {'form': form})

@login_required
def view_pickup_requests(request):
    """View all pickup requests for the logged-in user"""
    pickup_requests = PickupRequest.objects.filter(user=request.user)
    
    # Calculate status counts
    pending_count = pickup_requests.filter(status='pending').count()
    completed_count = pickup_requests.filter(status='completed').count()
    
    context = {
        'pickup_requests': pickup_requests,
        'pending_count': pending_count,
        'completed_count': completed_count,
    }
    return render(request, 'pickups/view_pickups.html', context)

@login_required
def pickup_detail(request, pk):
    """View details of a specific pickup request"""
    pickup_request = get_object_or_404(PickupRequest, pk=pk, user=request.user)
    return render(request, 'pickups/pickup_detail.html', {'pickup': pickup_request})

@login_required
def cancel_pickup_request(request, pk):
    """Cancel a pickup request"""
    pickup_request = get_object_or_404(PickupRequest, pk=pk, user=request.user)
    
    if pickup_request.status == 'pending':
        pickup_request.status = 'cancelled'
        pickup_request.save()
        messages.success(request, 'Pickup request cancelled successfully!')
    else:
        messages.error(request, 'Only pending requests can be cancelled.')
    
    return redirect('view_pickup_requests')


# ADMIN VIEWS - RENAMED TO AVOID CONFLICT
@login_required
def pickups_admin_dashboard(request):
    """Admin dashboard to manage all pickup requests"""
    # Check if user is admin
    if not request.user.is_admin_role():
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('user_dashboard')
    
    # Get all pickup requests with statistics
    all_requests = PickupRequest.objects.all().order_by('-created_at')
    
    # Filter by status if provided
    status_filter = request.GET.get('status', 'all')
    if status_filter != 'all':
        all_requests = all_requests.filter(status=status_filter)
    
    # Statistics
    stats = {
        'total': PickupRequest.objects.count(),
        'pending': PickupRequest.objects.filter(status='pending').count(),
        'accepted': PickupRequest.objects.filter(status='accepted').count(),
        'scheduled': PickupRequest.objects.filter(status='scheduled').count(),
        'on_the_way': PickupRequest.objects.filter(status='on_the_way').count(),
        'completed': PickupRequest.objects.filter(status='completed').count(),
        'cancelled': PickupRequest.objects.filter(status='cancelled').count(),
    }
    
    context = {
        'all_requests': all_requests,
        'stats': stats,
        'status_filter': status_filter,
    }
    return render(request, 'pickups/admin_dashboard.html', context)

@login_required
def admin_update_request(request, pk):
    """Admin view to update a pickup request"""
    # Check if user is admin
    if not request.user.is_admin_role():
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('user_dashboard')
    
    pickup_request = get_object_or_404(PickupRequest, pk=pk)
    
    if request.method == 'POST':
        status = request.POST.get('status')
        scheduled_date = request.POST.get('scheduled_date')
        admin_notes = request.POST.get('admin_notes')
        
        pickup_request.status = status
        if scheduled_date:
            pickup_request.scheduled_date = scheduled_date
        pickup_request.admin_notes = admin_notes
        pickup_request.save()
        
        messages.success(request, f'Request #{pk} updated successfully!')
        return redirect('pickups_admin_dashboard')
    
    return render(request, 'pickups/admin_update_request.html', {'pickup': pickup_request})