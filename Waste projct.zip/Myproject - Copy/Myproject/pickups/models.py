#pickups/models.py

from django.db import models
from django.conf import settings

class PickupRequest(models.Model):
    WASTE_TYPES = [
        ('plastic', 'Plastic'),
        ('paper', 'Paper'),
        ('glass', 'Glass'),
        ('metal', 'Metal'),
        ('electronic', 'Electronic Waste'),
        ('organic', 'Organic Waste'),
        ('mixed', 'Mixed Waste'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('scheduled', 'Scheduled'),
        ('on_the_way', 'On The Way'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='pickup_requests')
    waste_type = models.CharField(max_length=20, choices=WASTE_TYPES)
    quantity = models.DecimalField(max_digits=6, decimal_places=2, help_text="Quantity in kg")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    address = models.TextField()
    notes = models.TextField(blank=True, null=True)
    scheduled_date = models.DateField(blank=True, null=True, help_text="Date when pickup is scheduled")
    admin_notes = models.TextField(blank=True, null=True, help_text="Admin notes/updates for the user")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.waste_type} ({self.quantity}kg) - {self.status}"