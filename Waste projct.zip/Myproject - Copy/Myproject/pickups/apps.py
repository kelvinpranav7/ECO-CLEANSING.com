from django.apps import AppConfig


class PickupsConfig(AppConfig):
    name = 'pickups'
