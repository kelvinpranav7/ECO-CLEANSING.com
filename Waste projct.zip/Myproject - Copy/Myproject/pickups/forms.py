from django import forms
from .models import PickupRequest

class PickupRequestForm(forms.ModelForm):
    class Meta:
        model = PickupRequest
        fields = ['waste_type', 'quantity', 'address', 'notes']
        widgets = {
            'waste_type': forms.Select(attrs={
                'class': 'form-control',
                'placeholder': 'Select waste type'
            }),
            'quantity': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter quantity in kg',
                'step': '0.01',
                'min': '0.01'
            }),
            'address': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter pickup address',
                'rows': 3
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Any additional notes (optional)',
                'rows': 2
            }),
        }
        labels = {
            'waste_type': 'Type of Waste',
            'quantity': 'Quantity (kg)',
            'address': 'Pickup Address',
            'notes': 'Additional Notes',
        }