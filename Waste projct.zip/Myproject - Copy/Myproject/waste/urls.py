# waste/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # User URLs
    path('report/', views.report_street_waste, name='report_street_waste'),
    path('my-reports/', views.user_waste_history, name='user_waste_history'),
    path('detail/<int:pk>/', views.street_waste_detail, name='street_waste_detail'),
    
    # Admin URLs
    path('admin/street-wastes/', views.street_wastes_admin, name='street_wastes_admin'),
    path('admin/update/<int:pk>/', views.admin_update_street_waste, name='admin_update_street_waste'),
]