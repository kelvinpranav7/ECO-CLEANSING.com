# waste/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import StreetWaste
from .forms import StreetWasteReportForm, AdminStreetWasteUpdateForm

# USER VIEWS
@login_required
def report_street_waste(request):
    """User reports street waste with image and GPS location"""
    if request.method == 'POST':
        form = StreetWasteReportForm(request.POST, request.FILES)
        if form.is_valid():
            street_waste = form.save(commit=False)
            street_waste.user = request.user
            street_waste.save()
            messages.success(request, 'Street waste reported successfully! Admin will be notified.')
            return redirect('user_waste_history')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = StreetWasteReportForm()
    
    return render(request, 'waste/report_street_waste.html', {'form': form})

@login_required
def user_waste_history(request):
    """View user's own street waste reports"""
    reports = StreetWaste.objects.filter(user=request.user)
    
    # Statistics
    stats = {
        'total': reports.count(),
        'pending': reports.filter(status='pending').count(),
        'resolved': reports.filter(status='resolved').count(),
    }
    
    context = {
        'reports': reports,
        'stats': stats,
    }
    return render(request, 'waste/user_waste_history.html', context)

@login_required
def street_waste_detail(request, pk):
    """View details of a specific street waste report"""
    report = get_object_or_404(StreetWaste, pk=pk)
    
    # Users can only view their own reports, admins can view all
    if not request.user.is_admin_role() and report.user != request.user:
        messages.error(request, 'You do not have permission to view this report.')
        return redirect('user_waste_history')
    
    return render(request, 'waste/street_waste_detail.html', {'report': report})


# ADMIN VIEWS
@login_required
def street_wastes_admin(request):
    """Admin dashboard to view and manage all street waste reports"""
    if not request.user.is_admin_role():
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('user_dashboard')
    
    # Get all reports
    all_reports = StreetWaste.objects.all().order_by('-reported_at')
    
    # Filter by status if provided
    status_filter = request.GET.get('status', 'all')
    if status_filter != 'all':
        all_reports = all_reports.filter(status=status_filter)
    
    # Filter by severity
    severity_filter = request.GET.get('severity', 'all')
    if severity_filter != 'all':
        all_reports = all_reports.filter(severity=severity_filter)
    
    # Filter by category
    category_filter = request.GET.get('category', 'all')
    if category_filter != 'all':
        all_reports = all_reports.filter(category=category_filter)
    
    # Statistics
    stats = {
        'total': StreetWaste.objects.count(),
        'pending': StreetWaste.objects.filter(status='pending').count(),
        'assigned': StreetWaste.objects.filter(status='assigned').count(),
        'in_progress': StreetWaste.objects.filter(status='in_progress').count(),
        'collected': StreetWaste.objects.filter(status='collected').count(),
        'resolved': StreetWaste.objects.filter(status='resolved').count(),
    }
    
    context = {
        'all_reports': all_reports,
        'stats': stats,
        'status_filter': status_filter,
        'severity_filter': severity_filter,
        'category_filter': category_filter,
    }
    return render(request, 'waste/street_wastes_admin.html', context)

@login_required
def admin_update_street_waste(request, pk):
    """Admin updates street waste report status"""
    if not request.user.is_admin_role():
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('user_dashboard')
    
    report = get_object_or_404(StreetWaste, pk=pk)
    
    if request.method == 'POST':
        form = AdminStreetWasteUpdateForm(request.POST, instance=report)
        if form.is_valid():
            updated_report = form.save(commit=False)
            
            # Set resolved_at timestamp if status is resolved
            if updated_report.status == 'resolved' and not report.resolved_at:
                updated_report.resolved_at = timezone.now()
            
            updated_report.save()
            messages.success(request, f'Report #{pk} updated successfully!')
            return redirect('street_wastes_admin')
    else:
        form = AdminStreetWasteUpdateForm(instance=report)
    
    context = {
        'form': form,
        'report': report,
    }
    return render(request, 'waste/admin_update_street_waste.html', context)