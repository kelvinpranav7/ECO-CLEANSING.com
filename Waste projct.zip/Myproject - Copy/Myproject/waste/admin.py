# waste/admin.py
from django.contrib import admin
from .models import StreetWaste

@admin.register(StreetWaste)
class StreetWasteAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'category', 'severity', 'status', 'reported_at']
    list_filter = ['status', 'severity', 'category', 'reported_at']
    search_fields = ['user__username', 'description', 'location_address']
    readonly_fields = ['reported_at', 'updated_at', 'resolved_at']
    
    fieldsets = (
        ('Reporter Information', {
            'fields': ('user',)
        }),
        ('Waste Details', {
            'fields': ('category', 'severity', 'description', 'image')
        }),
        ('Location', {
            'fields': ('latitude', 'longitude', 'location_address')
        }),
        ('Management', {
            'fields': ('status', 'assigned_team', 'admin_notes')
        }),
        ('Timestamps', {
            'fields': ('reported_at', 'updated_at', 'resolved_at')
        }),
    )