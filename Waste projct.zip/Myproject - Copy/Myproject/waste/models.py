# waste/models.py
from django.db import models
from django.conf import settings

class StreetWaste(models.Model):
    CATEGORY_CHOICES = [
        ('plastic', 'Plastic Waste'),
        ('organic', 'Organic Waste'),
        ('electronic', 'Electronic Waste'),
        ('mixed', 'Mixed Waste'),
        ('other', 'Other'),
    ]
    
    SEVERITY_CHOICES = [
        ('low', 'Low - Minor issue'),
        ('medium', 'Medium - Noticeable problem'),
        ('high', 'High - Disturbing public (smell, blocking area)'),
        ('critical', 'Critical - Blocking roads/major hazard'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('assigned', 'Assigned to Team'),
        ('in_progress', 'Collection in Progress'),
        ('collected', 'Collected'),
        ('resolved', 'Resolved'),
    ]
    
    # Reporter Information
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='street_waste_reports'
    )
    
    # Waste Details
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES)
    description = models.TextField(blank=True, null=True, help_text="Additional details about the waste")
    image = models.ImageField(upload_to='street_waste_images/', help_text="Photo of the waste area")
    
    # Location Data
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    location_address = models.CharField(max_length=500, blank=True, null=True, help_text="Reverse geocoded address")
    
    # Status & Admin Management
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    assigned_team = models.CharField(max_length=100, blank=True, null=True, help_text="Team assigned for collection")
    admin_notes = models.TextField(blank=True, null=True, help_text="Internal notes from admin")
    
    # Timestamps
    reported_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        ordering = ['-reported_at']
        verbose_name = 'Street Waste Report'
        verbose_name_plural = 'Street Waste Reports'
    
    def __str__(self):
        return f"Report #{self.id} - {self.category} ({self.severity}) by {self.user.username}"
    
    def get_google_maps_link(self):
        """Generate Google Maps link for the location"""
        return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"