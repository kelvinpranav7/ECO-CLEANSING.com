# waste/forms.py
from django import forms
from .models import StreetWaste

class StreetWasteReportForm(forms.ModelForm):
    class Meta:
        model = StreetWaste
        fields = ['category', 'severity', 'description', 'image', 'latitude', 'longitude', 'location_address']
        widgets = {
            'category': forms.Select(attrs={
                'class': 'form-control',
                'required': True
            }),
            'severity': forms.Select(attrs={
                'class': 'form-control',
                'required': True
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Describe the waste situation (optional)',
                'rows': 3
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*',
                'capture': 'environment',  # Opens camera on mobile
                'required': True
            }),
            'latitude': forms.HiddenInput(attrs={
                'id': 'id_latitude',
                'required': True
            }),
            'longitude': forms.HiddenInput(attrs={
                'id': 'id_longitude',
                'required': True
            }),
            'location_address': forms.HiddenInput(attrs={
                'id': 'id_location_address'
            }),
        }
        labels = {
            'category': 'Waste Category',
            'severity': 'Severity Level',
            'description': 'Additional Details',
            'image': 'Upload Photo of Waste Area',
        }

class AdminStreetWasteUpdateForm(forms.ModelForm):
    class Meta:
        model = StreetWaste
        fields = ['status', 'assigned_team', 'admin_notes']
        widgets = {
            'status': forms.Select(attrs={
                'class': 'form-control'
            }),
            'assigned_team': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter team name or ID'
            }),
            'admin_notes': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Internal notes about this report',
                'rows': 3
            }),
        }